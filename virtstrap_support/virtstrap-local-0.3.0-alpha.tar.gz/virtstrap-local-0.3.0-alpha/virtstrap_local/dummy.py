def main():
    print '{"commands": [{"name": "install", "description": "desc"}]}'
    
if __name__ == "__main__":
    main()

